import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProblemStatement } from './components/ProblemStatement';
import { ProposedSolution } from './components/ProposedSolution';
import { Features } from './components/Features';
import { SystemArchitecture } from './components/SystemArchitecture';
import { TechnologyStack } from './components/TechnologyStack';
import { DashboardPreview } from './components/DashboardPreview';
import { FutureEnhancements } from './components/FutureEnhancements';
import { ProjectObjectives } from './components/ProjectObjectives';
import { ProjectImpact } from './components/ProjectImpact';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <div id="problem">
          <ProblemStatement />
        </div>
        <div id="solution">
          <ProposedSolution />
        </div>
        <Features />
        <div id="architecture">
          <SystemArchitecture />
        </div>
        <div id="technology">
          <TechnologyStack />
        </div>
        <div id="dashboard">
          <DashboardPreview />
        </div>
        <div id="future">
          <FutureEnhancements />
        </div>
        <div id="objectives">
          <ProjectObjectives />
        </div>
        <div id="impact">
          <ProjectImpact />
        </div>
      </main>
      <Footer />
    </div>
  );
}
