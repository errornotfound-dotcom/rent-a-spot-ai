import { motion } from 'motion/react';
import { User, Globe, Brain, Database, Home, ArrowDown } from 'lucide-react';

export function SystemArchitecture() {
  const layers = [
    {
      icon: User,
      title: 'Driver',
      description: 'Mobile/Web Interface',
      color: 'from-blue-400 to-cyan-500',
    },
    {
      icon: Globe,
      title: 'Web Platform',
      description: 'React Frontend + Node.js Backend',
      color: 'from-primary to-blue-500',
    },
    {
      icon: Brain,
      title: 'AI Recommendation Engine',
      description: 'Machine Learning Model',
      color: 'from-secondary to-purple-500',
    },
    {
      icon: Database,
      title: 'Database',
      description: 'MongoDB Cloud Storage',
      color: 'from-green-400 to-emerald-500',
    },
    {
      icon: Home,
      title: 'Parking Space Owners',
      description: 'Property Management Dashboard',
      color: 'from-yellow-400 to-orange-500',
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <Database className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">System Design</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            System <span className="text-primary">Architecture</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Multi-layered architecture with AI-powered recommendation engine
          </p>
        </motion.div>

        {/* Architecture Diagram */}
        <div className="max-w-3xl mx-auto space-y-6">
          {layers.map((layer, index) => (
            <div key={layer.title}>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative group"
              >
                <div className="relative p-8 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all">
                  {/* Glow Effect */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${layer.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                  <div className="relative flex items-center gap-6">
                    {/* Icon */}
                    <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${layer.color} p-0.5 flex-shrink-0`}>
                      <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                        <layer.icon className={`w-8 h-8 bg-gradient-to-br ${layer.color} bg-clip-text text-transparent`} />
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold mb-1">{layer.title}</h3>
                      <p className="text-muted-foreground">{layer.description}</p>
                    </div>

                    {/* Layer Number */}
                    <div className="text-6xl font-extrabold text-muted-foreground/10">
                      {index + 1}
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Connector Arrow */}
              {index < layers.length - 1 && (
                <motion.div
                  initial={{ opacity: 0, scaleY: 0 }}
                  whileInView={{ opacity: 1, scaleY: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.1 + 0.3 }}
                  viewport={{ once: true }}
                  className="flex justify-center py-3"
                >
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-primary to-secondary blur-lg opacity-50" />
                    <ArrowDown className="w-8 h-8 text-primary relative" strokeWidth={3} />
                  </div>
                </motion.div>
              )}
            </div>
          ))}
        </div>

        {/* Architecture Notes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto"
        >
          <div className="p-6 rounded-2xl bg-card backdrop-blur-xl border border-border text-center">
            <div className="text-3xl font-bold text-primary mb-2">3-Tier</div>
            <div className="text-sm text-muted-foreground">Architecture Model</div>
          </div>
          <div className="p-6 rounded-2xl bg-card backdrop-blur-xl border border-border text-center">
            <div className="text-3xl font-bold text-primary mb-2">RESTful</div>
            <div className="text-sm text-muted-foreground">API Design</div>
          </div>
          <div className="p-6 rounded-2xl bg-card backdrop-blur-xl border border-border text-center">
            <div className="text-3xl font-bold text-primary mb-2">Cloud</div>
            <div className="text-sm text-muted-foreground">Scalable Infrastructure</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
