import { motion } from 'motion/react';
import { Check, Sparkles, Crown, Rocket } from 'lucide-react';

export function Pricing() {
  const plans = [
    {
      name: 'Free',
      icon: Sparkles,
      price: '0',
      description: 'Perfect for occasional parkers',
      features: [
        'Search parking spaces',
        'Real-time availability',
        'Basic booking features',
        'Email support',
        'Standard search results',
      ],
      cta: 'Get Started',
      popular: false,
      gradient: 'from-gray-400 to-gray-600',
    },
    {
      name: 'Premium',
      icon: Crown,
      price: '9.99',
      description: 'For frequent drivers',
      features: [
        'Everything in Free',
        'AI-powered recommendations',
        'Priority booking',
        'No booking fees',
        '24/7 priority support',
        'Advanced search filters',
        'Booking history & analytics',
      ],
      cta: 'Start Premium',
      popular: true,
      gradient: 'from-primary to-secondary',
    },
    {
      name: 'Business',
      icon: Rocket,
      price: '49.99',
      description: 'For teams and businesses',
      features: [
        'Everything in Premium',
        'Team management',
        'Bulk booking discounts',
        'Custom integrations',
        'Dedicated account manager',
        'Analytics dashboard',
        'API access',
        'White-label options',
      ],
      cta: 'Contact Sales',
      popular: false,
      gradient: 'from-yellow-400 to-orange-500',
    },
  ];

  return (
    <section id="pricing" className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Simple, <span className="text-primary">Transparent Pricing</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Choose the plan that fits your parking needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`relative ${plan.popular ? 'md:-translate-y-4' : ''}`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-primary to-secondary text-sm font-semibold whitespace-nowrap">
                  Most Popular
                </div>
              )}

              <div className={`relative h-full p-8 rounded-2xl bg-card backdrop-blur-xl border-2 ${plan.popular ? 'border-primary' : 'border-border'} transition-all`}>
                {/* Gradient Glow */}
                {plan.popular && (
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl" />
                )}

                <div className="relative space-y-6">
                  {/* Icon & Name */}
                  <div className="space-y-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.gradient} p-0.5`}>
                      <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                        <plan.icon className={`w-6 h-6 bg-gradient-to-br ${plan.gradient} bg-clip-text text-transparent`} />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{plan.name}</h3>
                      <p className="text-muted-foreground text-sm">{plan.description}</p>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="flex items-baseline gap-1">
                    <span className="text-5xl font-extrabold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                      ${plan.price}
                    </span>
                    <span className="text-muted-foreground">/month</span>
                  </div>

                  {/* Features */}
                  <ul className="space-y-3">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <button
                    className={`w-full px-6 py-3 rounded-xl font-semibold transition-all ${
                      plan.popular
                        ? 'bg-primary text-primary-foreground hover:shadow-[0_0_30px_rgba(0,229,255,0.5)]'
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }`}
                  >
                    {plan.cta}
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Property Owners CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 text-center"
        >
          <h3 className="text-2xl font-bold mb-2">Property Owners</h3>
          <p className="text-muted-foreground mb-6">
            List your parking space and earn passive income. We only take a small commission when you get bookings.
          </p>
          <button className="px-8 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:shadow-[0_0_30px_rgba(0,229,255,0.5)] transition-all">
            Start Earning Today
          </button>
        </motion.div>
      </div>
    </section>
  );
}
