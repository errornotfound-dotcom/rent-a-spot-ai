import { motion } from 'motion/react';
import { Brain, MapPin, DollarSign, Zap, Shield, BarChart3, Clock, Sparkles } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: Brain,
      title: 'AI-Powered Predictions',
      description: 'Advanced machine learning algorithms predict parking demand and optimize your search results.',
      gradient: 'from-primary to-blue-500',
    },
    {
      icon: MapPin,
      title: 'Smart Location Matching',
      description: 'Find the perfect parking spot based on your destination, preferences, and real-time availability.',
      gradient: 'from-secondary to-purple-500',
    },
    {
      icon: DollarSign,
      title: 'Dynamic Pricing',
      description: 'Fair, transparent pricing that adjusts based on demand, ensuring the best value for drivers and owners.',
      gradient: 'from-green-400 to-emerald-500',
    },
    {
      icon: Zap,
      title: 'Instant Booking',
      description: 'Reserve your parking space in seconds with our lightning-fast booking system.',
      gradient: 'from-yellow-400 to-orange-500',
    },
    {
      icon: Shield,
      title: 'Secure Transactions',
      description: 'Bank-level security and encrypted payments protect your financial information.',
      gradient: 'from-blue-400 to-cyan-500',
    },
    {
      icon: BarChart3,
      title: 'Revenue Analytics',
      description: 'Property owners get detailed insights and forecasting to maximize their parking space earnings.',
      gradient: 'from-pink-400 to-rose-500',
    },
    {
      icon: Clock,
      title: '24/7 Availability',
      description: 'Access parking spaces around the clock with automated check-in and check-out.',
      gradient: 'from-indigo-400 to-violet-500',
    },
    {
      icon: Sparkles,
      title: 'Smart Recommendations',
      description: 'Get personalized parking suggestions based on your history and preferences.',
      gradient: 'from-primary to-secondary',
    },
  ];

  return (
    <section id="features" className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">AI Features</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            The Future of <span className="text-primary">Smart Parking</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Experience parking powered by cutting-edge artificial intelligence and modern technology
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative h-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all">
                {/* Gradient Glow on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-4">
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} p-0.5`}>
                    <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                      <feature.icon className={`w-6 h-6 bg-gradient-to-br ${feature.gradient} bg-clip-text text-transparent`} />
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-semibold">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
