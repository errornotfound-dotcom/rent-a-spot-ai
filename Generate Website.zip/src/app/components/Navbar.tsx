import { Zap, Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
              <Zap className="w-8 h-8 text-primary relative" fill="currentColor" />
            </div>
            <span className="text-2xl font-extrabold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              PARK EASY
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#problem" className="text-muted-foreground hover:text-foreground transition-colors">
              Problem
            </a>
            <a href="#solution" className="text-muted-foreground hover:text-foreground transition-colors">
              Solution
            </a>
            <a href="#architecture" className="text-muted-foreground hover:text-foreground transition-colors">
              Architecture
            </a>
            <a href="#technology" className="text-muted-foreground hover:text-foreground transition-colors">
              Technology
            </a>
            <a href="#impact" className="text-muted-foreground hover:text-foreground transition-colors">
              Impact
            </a>
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <button className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:shadow-[0_0_30px_rgba(0,229,255,0.5)] transition-all">
              View Demo
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-4 border-t border-border">
            <a href="#problem" className="block text-muted-foreground hover:text-foreground transition-colors">
              Problem
            </a>
            <a href="#solution" className="block text-muted-foreground hover:text-foreground transition-colors">
              Solution
            </a>
            <a href="#architecture" className="block text-muted-foreground hover:text-foreground transition-colors">
              Architecture
            </a>
            <a href="#technology" className="block text-muted-foreground hover:text-foreground transition-colors">
              Technology
            </a>
            <a href="#impact" className="block text-muted-foreground hover:text-foreground transition-colors">
              Impact
            </a>
            <div className="pt-4">
              <button className="w-full px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold">
                View Demo
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
