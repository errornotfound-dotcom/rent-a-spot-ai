import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import { useState } from 'react';

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'How does Park Easy work?',
      answer: 'Park Easy connects drivers looking for parking with property owners who have available spaces. Simply search for parking near your destination, select a spot, book and pay securely, then use your digital QR code to access the parking space.',
    },
    {
      question: 'Is my payment information secure?',
      answer: 'Absolutely. We use bank-level encryption and comply with PCI DSS standards to ensure your payment information is completely secure. We never store your full credit card details on our servers.',
    },
    {
      question: 'Can I cancel my booking?',
      answer: 'Yes, you can cancel your booking up to 1 hour before the start time for a full refund. Cancellations within 1 hour of the booking start time may incur a small fee.',
    },
    {
      question: 'How do I become a property owner on Park Easy?',
      answer: 'Simply sign up, verify your property ownership, list your parking space with photos and details, set your availability and pricing, and start earning when drivers book your space.',
    },
    {
      question: 'What happens if the parking space is occupied when I arrive?',
      answer: 'If your reserved space is occupied, contact our 24/7 support immediately. We\'ll help resolve the issue and provide you with an alternative parking option or a full refund.',
    },
    {
      question: 'Do you support electric vehicle charging?',
      answer: 'Yes! Many of our parking spaces include EV charging stations. You can filter search results to show only parking spots with charging capabilities.',
    },
    {
      question: 'How does the AI recommendation system work?',
      answer: 'Our AI analyzes factors like your destination, preferred price range, parking duration, past booking history, and real-time availability to recommend the best parking options tailored to your needs.',
    },
    {
      question: 'Is there a mobile app available?',
      answer: 'Yes, Park Easy is available on both iOS and Android. Download the app from the App Store or Google Play to book parking on the go.',
    },
  ];

  return (
    <section id="faq" className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Frequently Asked <span className="text-primary">Questions</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about Park Easy
          </p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all text-left"
              >
                <div className="flex items-center justify-between gap-4">
                  <h3 className="font-semibold text-lg">{faq.question}</h3>
                  <ChevronDown
                    className={`w-5 h-5 text-primary flex-shrink-0 transition-transform ${
                      openIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </div>
                {openIndex === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-4 text-muted-foreground leading-relaxed"
                  >
                    {faq.answer}
                  </motion.div>
                )}
              </button>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-12 text-center p-8 rounded-2xl bg-card backdrop-blur-xl border border-border"
        >
          <h3 className="text-xl font-bold mb-2">Still have questions?</h3>
          <p className="text-muted-foreground mb-6">
            Our support team is here to help you 24/7
          </p>
          <button className="px-8 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:shadow-[0_0_30px_rgba(0,229,255,0.5)] transition-all">
            Contact Support
          </button>
        </motion.div>
      </div>
    </section>
  );
}
