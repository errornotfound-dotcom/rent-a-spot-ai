import { Zap, Facebook, Twitter, Instagram, Linkedin, Github } from 'lucide-react';

export function Footer() {
  const links = {
    project: [
      { name: 'Problem Statement', href: '#problem' },
      { name: 'Solution', href: '#solution' },
      { name: 'Architecture', href: '#architecture' },
      { name: 'Technology Stack', href: '#technology' },
    ],
    research: [
      { name: 'Project Objectives', href: '#objectives' },
      { name: 'Project Impact', href: '#impact' },
      { name: 'Future Enhancements', href: '#future' },
      { name: 'Dashboard Preview', href: '#dashboard' },
    ],
    resources: [
      { name: 'Documentation', href: '#' },
      { name: 'GitHub Repository', href: '#' },
      { name: 'Technical Paper', href: '#' },
      { name: 'Presentation', href: '#' },
    ],
    contact: [
      { name: 'Project Team', href: '#' },
      { name: 'Faculty Guide', href: '#' },
      { name: 'Department', href: '#' },
      { name: 'Institution', href: '#' },
    ],
  };

  const socials = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Github, href: '#', label: 'GitHub' },
  ];

  return (
    <footer className="relative border-t border-border">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-background-secondary" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
                <Zap className="w-8 h-8 text-primary relative" fill="currentColor" />
              </div>
              <span className="text-2xl font-extrabold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                PARK EASY
              </span>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              An AI-powered smart parking ecosystem using Machine Learning for intelligent parking space recommendations and urban mobility optimization.
            </p>
            {/* Social Links */}
            <div className="flex items-center gap-3 pt-2">
              {socials.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="p-2 rounded-lg bg-card border border-border hover:border-primary/50 hover:bg-muted transition-all"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-semibold mb-4">Project</h3>
            <ul className="space-y-3">
              {links.project.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-muted-foreground hover:text-primary transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Research</h3>
            <ul className="space-y-3">
              {links.research.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-muted-foreground hover:text-primary transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Resources</h3>
            <ul className="space-y-3">
              {links.resources.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-muted-foreground hover:text-primary transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <ul className="space-y-3">
              {links.contact.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-muted-foreground hover:text-primary transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Academic Info */}
        <div className="py-8 border-t border-border">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h3 className="text-xl font-bold">Academic Innovation Project</h3>
            <p className="text-muted-foreground">
              This project demonstrates the application of AI and Machine Learning technologies to solve real-world urban mobility challenges.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-1">Project Type</div>
                <div className="font-semibold">Final Year Project</div>
              </div>
              <div className="p-4 rounded-xl bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-1">Category</div>
                <div className="font-semibold">Smart City & IoT</div>
              </div>
              <div className="p-4 rounded-xl bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-1">Year</div>
                <div className="font-semibold">2025-2026</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>© 2026 Park Easy Innovation Project. Academic Research & Development.</p>
            <p>
              Built with <span className="text-primary">♥</span> for sustainable smart cities
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
