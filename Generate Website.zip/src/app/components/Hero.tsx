import { motion } from 'motion/react';
import { Lightbulb } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
        <img
          src="https://images.unsplash.com/photo-1747499967281-c0c5eec9933c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwY2l0eSUyMG5pZ2h0JTIwbmVvbiUyMGxpZ2h0cyUyMHNtYXJ0JTIwY2l0eXxlbnwxfHx8fDE3ODAzMjAyODJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Futuristic city at night"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />

        {/* Glow Effects */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-[120px]" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="text-center space-y-8">
          {/* Innovation Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border"
          >
            <Lightbulb className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Innovation Project</span>
          </motion.div>

          {/* Hero Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl sm:text-6xl lg:text-7xl font-extrabold leading-tight"
          >
            <span className="bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent animate-gradient">
              PARK EASY
            </span>
            <br />
            <span className="text-3xl sm:text-4xl lg:text-5xl">
              AI-Powered Smart Parking Ecosystem
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto"
          >
            A Machine Learning-based parking reservation and space rental marketplace for sustainable urban mobility
          </motion.p>

          {/* Project Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap items-center justify-center gap-4 pt-4"
          >
            <div className="px-6 py-3 rounded-xl bg-card backdrop-blur-xl border border-border">
              <div className="text-sm text-muted-foreground mb-1">Domain</div>
              <div className="font-semibold">Smart City & IoT</div>
            </div>
            <div className="px-6 py-3 rounded-xl bg-card backdrop-blur-xl border border-border">
              <div className="text-sm text-muted-foreground mb-1">Technology</div>
              <div className="font-semibold">AI & Machine Learning</div>
            </div>
            <div className="px-6 py-3 rounded-xl bg-card backdrop-blur-xl border border-border">
              <div className="text-sm text-muted-foreground mb-1">Category</div>
              <div className="font-semibold">Urban Mobility</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-2">
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1.5 h-1.5 bg-primary rounded-full"
          />
        </div>
      </motion.div>
    </section>
  );
}
