import { motion } from 'motion/react';
import { Smartphone, Brain, Search, CalendarCheck, CreditCard, QrCode, MapPin } from 'lucide-react';
import { ChevronDown } from 'lucide-react';

export function ProposedSolution() {
  const workflow = [
    {
      icon: Smartphone,
      title: 'Driver Opens App',
      description: 'User launches the Park Easy mobile or web application',
    },
    {
      icon: Brain,
      title: 'AI Finds Best Parking',
      description: 'Machine learning algorithm analyzes location, preferences, and availability',
    },
    {
      icon: Search,
      title: 'Compare Available Spaces',
      description: 'View multiple parking options with real-time pricing and distance',
    },
    {
      icon: CalendarCheck,
      title: 'Book Slot',
      description: 'Reserve parking space with selected time duration',
    },
    {
      icon: CreditCard,
      title: 'Secure Payment',
      description: 'Complete transaction through integrated payment gateway',
    },
    {
      icon: QrCode,
      title: 'Receive QR Code',
      description: 'Digital access code generated for parking entry',
    },
    {
      icon: MapPin,
      title: 'Enter Parking Area',
      description: 'Scan QR code at parking facility for automated access',
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="text-sm text-muted-foreground">Proposed Solution</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Intelligent Parking <span className="text-primary">Workflow</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            AI-driven end-to-end parking solution with seamless user experience
          </p>
        </motion.div>

        {/* Workflow Steps */}
        <div className="max-w-4xl mx-auto space-y-8">
          {workflow.map((step, index) => (
            <div key={step.title}>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative"
              >
                <div className="flex items-start gap-6 p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all group">
                  {/* Step Number & Icon */}
                  <div className="flex-shrink-0 relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary to-secondary blur-xl opacity-0 group-hover:opacity-50 transition-all" />
                    <div className="relative w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-secondary p-0.5">
                      <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                        <step.icon className="w-8 h-8 text-primary" />
                      </div>
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-lg bg-primary/20 backdrop-blur-xl border border-primary/50 flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 pt-2">
                    <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </motion.div>

              {/* Connector */}
              {index < workflow.length - 1 && (
                <motion.div
                  initial={{ opacity: 0, scaleY: 0 }}
                  whileInView={{ opacity: 1, scaleY: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.1 + 0.3 }}
                  viewport={{ once: true }}
                  className="flex justify-center py-4"
                >
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-primary to-secondary blur-md opacity-50" />
                    <ChevronDown className="w-6 h-6 text-primary relative animate-bounce" style={{ animationDuration: '2s' }} />
                  </div>
                </motion.div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
