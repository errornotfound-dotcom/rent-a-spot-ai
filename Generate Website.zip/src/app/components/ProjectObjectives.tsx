import { motion } from 'motion/react';
import { Target, Clock, Car, DollarSign, Building2 } from 'lucide-react';

export function ProjectObjectives() {
  const objectives = [
    {
      icon: Clock,
      title: 'Reduce Parking Search Time',
      description: 'Minimize time spent searching for parking by 70% through AI-powered recommendations',
      metric: '70%',
      color: 'from-blue-400 to-cyan-500',
    },
    {
      icon: Car,
      title: 'Reduce Traffic Congestion',
      description: 'Decrease traffic congestion caused by parking search in urban areas',
      metric: '30%',
      color: 'from-red-400 to-orange-500',
    },
    {
      icon: Target,
      title: 'Improve User Convenience',
      description: 'Provide seamless booking experience with instant confirmation and digital access',
      metric: '95%',
      color: 'from-green-400 to-emerald-500',
    },
    {
      icon: DollarSign,
      title: 'Generate Revenue for Property Owners',
      description: 'Enable property owners to monetize unused parking spaces effectively',
      metric: '+40%',
      color: 'from-yellow-400 to-amber-500',
    },
    {
      icon: Building2,
      title: 'Support Smart City Development',
      description: 'Contribute to smart city infrastructure with data-driven parking management',
      metric: '100%',
      color: 'from-primary to-secondary',
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <Target className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Goals</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Project <span className="text-primary">Objectives</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Core goals driving the Park Easy innovation project
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {objectives.map((objective, index) => (
            <motion.div
              key={objective.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative h-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all">
                <div className={`absolute inset-0 bg-gradient-to-br ${objective.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${objective.color} p-0.5 flex-shrink-0`}>
                      <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                        <objective.icon className={`w-6 h-6 bg-gradient-to-br ${objective.color} bg-clip-text text-transparent`} />
                      </div>
                    </div>
                    <div className={`text-3xl font-extrabold bg-gradient-to-br ${objective.color} bg-clip-text text-transparent`}>
                      {objective.metric}
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold">{objective.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{objective.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
