import { motion } from 'motion/react';
import { Fuel, Car, TrendingUp, Laptop, Leaf } from 'lucide-react';

export function ProjectImpact() {
  const impacts = [
    {
      icon: Fuel,
      title: 'Less Fuel Waste',
      description: 'Reduced fuel consumption from eliminated parking search time',
      benefit: 'Environmental & Economic',
      color: 'from-green-400 to-emerald-500',
    },
    {
      icon: Car,
      title: 'Reduced Traffic',
      description: 'Decreased congestion in urban areas through optimized parking allocation',
      benefit: 'Urban Mobility',
      color: 'from-blue-400 to-cyan-500',
    },
    {
      icon: TrendingUp,
      title: 'Better Parking Utilization',
      description: 'Maximized use of available parking infrastructure through smart allocation',
      benefit: 'Resource Optimization',
      color: 'from-purple-400 to-pink-500',
    },
    {
      icon: Laptop,
      title: 'Digital Parking Management',
      description: 'Paperless, automated parking operations with real-time tracking',
      benefit: 'Digital Transformation',
      color: 'from-primary to-secondary',
    },
    {
      icon: Leaf,
      title: 'Sustainable Urban Mobility',
      description: 'Support for eco-friendly transportation and smart city initiatives',
      benefit: 'Sustainability',
      color: 'from-green-500 to-teal-500',
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-green-500/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <Leaf className="w-4 h-4 text-green-400" />
            <span className="text-sm text-muted-foreground">Impact Assessment</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Project <span className="text-primary">Impact</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Positive outcomes and benefits for society, environment, and urban infrastructure
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {impacts.map((impact, index) => (
            <motion.div
              key={impact.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative h-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-green-400/50 transition-all">
                <div className={`absolute inset-0 bg-gradient-to-br ${impact.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${impact.color} p-0.5`}>
                    <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                      <impact.icon className={`w-6 h-6 bg-gradient-to-br ${impact.color} bg-clip-text text-transparent`} />
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold">{impact.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{impact.description}</p>

                  <div className="pt-2">
                    <span className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-green-400/10 border border-green-400/30 text-xs font-semibold text-green-400">
                      {impact.benefit}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Impact Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="p-8 rounded-2xl bg-gradient-to-br from-green-400/10 to-emerald-500/10 border border-green-400/20 text-center"
        >
          <h3 className="text-2xl font-bold mb-4">Sustainable Development Goals</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div>
              <div className="text-3xl font-extrabold text-green-400 mb-2">SDG 9</div>
              <p className="text-sm text-muted-foreground">Industry, Innovation & Infrastructure</p>
            </div>
            <div>
              <div className="text-3xl font-extrabold text-green-400 mb-2">SDG 11</div>
              <p className="text-sm text-muted-foreground">Sustainable Cities & Communities</p>
            </div>
            <div>
              <div className="text-3xl font-extrabold text-green-400 mb-2">SDG 13</div>
              <p className="text-sm text-muted-foreground">Climate Action</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
