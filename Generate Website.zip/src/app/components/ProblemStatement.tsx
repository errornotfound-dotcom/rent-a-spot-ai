import { motion } from 'motion/react';
import { Clock, Fuel, Car, Frown } from 'lucide-react';

export function ProblemStatement() {
  const problems = [
    {
      icon: Clock,
      title: 'Time Wasted Searching for Parking',
      description: 'Average 20 minutes per trip spent searching for available parking spots',
      color: 'from-red-400 to-orange-500',
    },
    {
      icon: Fuel,
      title: 'Increased Fuel Consumption',
      description: 'Unnecessary fuel consumption while circling to find parking spaces',
      color: 'from-yellow-400 to-amber-500',
    },
    {
      icon: Car,
      title: 'Traffic Congestion',
      description: 'Parking search contributes to 30% of urban traffic congestion',
      color: 'from-orange-500 to-red-500',
    },
    {
      icon: Frown,
      title: 'Driver Frustration',
      description: 'Stress and anxiety from uncertain parking availability',
      color: 'from-purple-400 to-pink-500',
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <div className="w-2 h-2 bg-red-500 rounded-full" />
            <span className="text-sm text-muted-foreground">Problem Statement</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Parking Shouldn't Be a <span className="text-red-400">Daily Struggle</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Urban parking challenges create cascading problems affecting time, resources, and quality of life
          </p>
        </motion.div>

        {/* Visual Representation */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16 rounded-3xl overflow-hidden border border-border bg-card backdrop-blur-xl"
        >
          <div className="relative h-80">
            <img
              src="https://images.unsplash.com/photo-1747499967281-c0c5eec9933c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwY2l0eSUyMG5pZ2h0JTIwbmVvbiUyMGxpZ2h0cyUyMHNtYXJ0JTIwY2l0eXxlbnwxfHx8fDE3ODAzMjAyODJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="City traffic congestion"
              className="w-full h-full object-cover opacity-40"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center space-y-4">
                <motion.div
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  viewport={{ once: true }}
                  className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-red-500/20 backdrop-blur-xl border border-red-500/50"
                >
                  <Car className="w-10 h-10 text-red-400" />
                </motion.div>
                <p className="text-2xl font-bold">Vehicles searching for parking in congested areas</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Problem Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {problems.map((problem, index) => (
            <motion.div
              key={problem.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative h-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-red-400/50 transition-all">
                {/* Gradient Glow */}
                <div className={`absolute inset-0 bg-gradient-to-br ${problem.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-4">
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${problem.color} p-0.5`}>
                    <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                      <problem.icon className={`w-6 h-6 bg-gradient-to-br ${problem.color} bg-clip-text text-transparent`} />
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-semibold">{problem.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{problem.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
