import { motion } from 'motion/react';
import { Zap, Cpu, Building2, TrendingUp, Mic, Car } from 'lucide-react';

export function FutureEnhancements() {
  const enhancements = [
    {
      icon: Zap,
      title: 'EV Charging Integration',
      description: 'Smart electric vehicle charging stations with dynamic pricing and availability tracking',
      color: 'from-green-400 to-emerald-500',
    },
    {
      icon: Cpu,
      title: 'IoT Parking Sensors',
      description: 'Real-time occupancy detection using Internet of Things sensors and automated space updates',
      color: 'from-blue-400 to-cyan-500',
    },
    {
      icon: Building2,
      title: 'Smart City Integration',
      description: 'Integration with urban traffic management systems for city-wide parking optimization',
      color: 'from-purple-400 to-pink-500',
    },
    {
      icon: TrendingUp,
      title: 'Traffic Prediction',
      description: 'AI-powered traffic forecasting to recommend optimal parking times and routes',
      color: 'from-primary to-secondary',
    },
    {
      icon: Mic,
      title: 'Voice Assistant',
      description: 'Hands-free parking search and booking through voice commands and AI assistant',
      color: 'from-yellow-400 to-orange-500',
    },
    {
      icon: Car,
      title: 'Autonomous Vehicle Compatibility',
      description: 'Automated parking for self-driving vehicles with seamless integration',
      color: 'from-red-400 to-rose-500',
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Roadmap</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Future <span className="text-primary">Enhancements</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Planned features and innovations to advance the Park Easy ecosystem
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {enhancements.map((enhancement, index) => (
            <motion.div
              key={enhancement.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative h-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all">
                <div className={`absolute inset-0 bg-gradient-to-br ${enhancement.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${enhancement.color} p-0.5`}>
                    <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                      <enhancement.icon className={`w-6 h-6 bg-gradient-to-br ${enhancement.color} bg-clip-text text-transparent`} />
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold">{enhancement.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{enhancement.description}</p>

                  <div className="pt-2">
                    <span className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-primary/10 border border-primary/30 text-xs font-semibold text-primary">
                      Planned
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
