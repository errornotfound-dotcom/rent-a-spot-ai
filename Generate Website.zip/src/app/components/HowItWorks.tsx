import { motion } from 'motion/react';
import { Search, CalendarCheck, CreditCard, QrCode } from 'lucide-react';

export function HowItWorks() {
  const steps = [
    {
      icon: Search,
      title: 'Search & Discover',
      description: 'Enter your destination and let our AI find the best parking options for you.',
      color: 'from-primary to-cyan-500',
    },
    {
      icon: CalendarCheck,
      title: 'Select & Reserve',
      description: 'Choose your preferred spot and time slot with real-time availability updates.',
      color: 'from-secondary to-purple-500',
    },
    {
      icon: CreditCard,
      title: 'Secure Payment',
      description: 'Complete your booking with our fast, secure payment system.',
      color: 'from-green-400 to-emerald-500',
    },
    {
      icon: QrCode,
      title: 'Park & Go',
      description: 'Access your parking spot with a digital QR code. No hassle, no waiting.',
      color: 'from-yellow-400 to-orange-500',
    },
  ];

  return (
    <section id="how-it-works" className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            How It <span className="text-primary">Works</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Four simple steps to stress-free parking
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connection Lines (Desktop) */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-secondary to-primary opacity-20" />

          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="flex flex-col items-center text-center space-y-4">
                {/* Step Number */}
                <div className="relative">
                  <div className={`absolute inset-0 bg-gradient-to-br ${step.color} blur-xl opacity-50`} />
                  <div className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} p-0.5`}>
                    <div className="w-full h-full rounded-2xl bg-background flex items-center justify-center">
                      <step.icon className={`w-8 h-8 bg-gradient-to-br ${step.color} bg-clip-text text-transparent`} />
                    </div>
                  </div>
                </div>

                {/* Step Badge */}
                <div className="px-4 py-1 rounded-full bg-card backdrop-blur-xl border border-border text-sm text-muted-foreground">
                  Step {index + 1}
                </div>

                {/* Content */}
                <h3 className="text-xl font-semibold">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{step.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <button className="group relative px-8 py-4 rounded-xl bg-primary text-primary-foreground font-semibold hover:shadow-[0_0_40px_rgba(0,229,255,0.6)] transition-all overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="relative">Start Parking Smarter</span>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
