import { motion } from 'motion/react';
import { MapPin, Car, TrendingUp, DollarSign, Sparkles, Activity } from 'lucide-react';

export function DashboardPreview() {
  const metrics = [
    {
      icon: MapPin,
      label: 'Available Parking Spaces',
      value: '342',
      change: '+12%',
      color: 'from-green-400 to-emerald-500',
    },
    {
      icon: Car,
      label: 'Occupied Spaces',
      value: '158',
      change: '+8%',
      color: 'from-blue-400 to-cyan-500',
    },
    {
      icon: TrendingUp,
      label: 'AI Recommendation Score',
      value: '94%',
      change: '+5%',
      color: 'from-primary to-secondary',
    },
    {
      icon: DollarSign,
      label: 'Estimated Parking Cost',
      value: '₹45',
      change: 'per hour',
      color: 'from-yellow-400 to-orange-500',
    },
  ];

  const suggestions = [
    {
      location: 'Green Valley Complex, Sector 12',
      distance: '0.3 km',
      price: '₹30/hr',
      aiScore: 98,
      features: ['EV Charging', 'Covered', 'Security'],
    },
    {
      location: 'Metro Mall Parking, City Center',
      distance: '0.5 km',
      price: '₹40/hr',
      aiScore: 95,
      features: ['24/7 Access', 'CCTV', 'Well-lit'],
    },
    {
      location: 'Tech Park Basement, IT Hub',
      distance: '0.8 km',
      price: '₹25/hr',
      aiScore: 92,
      features: ['Indoor', 'Reserved', 'Accessible'],
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <Activity className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Live Dashboard</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Dashboard <span className="text-primary">Preview</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Real-time analytics and AI-powered parking recommendations
          </p>
        </motion.div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all">
                <div className={`absolute inset-0 bg-gradient-to-br ${metric.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-3">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${metric.color} p-0.5`}>
                    <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                      <metric.icon className={`w-5 h-5 bg-gradient-to-br ${metric.color} bg-clip-text text-transparent`} />
                    </div>
                  </div>

                  <div className="text-sm text-muted-foreground">{metric.label}</div>
                  <div className="flex items-baseline gap-2">
                    <div className="text-3xl font-extrabold">{metric.value}</div>
                    <div className="text-sm text-green-400">{metric.change}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Smart Suggestions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="p-8 rounded-2xl bg-card backdrop-blur-xl border border-border"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary p-0.5">
              <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
            </div>
            <h3 className="text-2xl font-bold">AI Smart Suggestions</h3>
          </div>

          <div className="space-y-4">
            {suggestions.map((suggestion, index) => (
              <motion.div
                key={suggestion.location}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="p-4 rounded-xl bg-muted/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all"
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex-1">
                    <div className="font-semibold mb-1">{suggestion.location}</div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {suggestion.distance}
                      </span>
                      <span className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        {suggestion.price}
                      </span>
                    </div>
                  </div>
                  <div className="px-3 py-1 rounded-lg bg-primary/20 border border-primary/50 text-sm font-semibold text-primary">
                    AI Score: {suggestion.aiScore}%
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {suggestion.features.map((feature) => (
                    <span
                      key={feature}
                      className="px-3 py-1 rounded-lg bg-background/50 border border-border text-xs"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
