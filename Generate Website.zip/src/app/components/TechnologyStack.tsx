import { motion } from 'motion/react';
import { Code2, Server, Database, Brain, Map, Shield, CreditCard } from 'lucide-react';

export function TechnologyStack() {
  const techStack = [
    {
      category: 'Frontend',
      icon: Code2,
      color: 'from-blue-400 to-cyan-500',
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'React.js', 'Tailwind CSS'],
    },
    {
      category: 'Backend',
      icon: Server,
      color: 'from-green-400 to-emerald-500',
      technologies: ['Node.js', 'Express.js', 'RESTful API'],
    },
    {
      category: 'Database',
      icon: Database,
      color: 'from-purple-400 to-pink-500',
      technologies: ['MongoDB', 'Mongoose ODM', 'Cloud Atlas'],
    },
    {
      category: 'AI Layer',
      icon: Brain,
      color: 'from-primary to-secondary',
      technologies: ['Machine Learning', 'Recommendation Engine', 'Predictive Analytics'],
    },
    {
      category: 'Maps',
      icon: Map,
      color: 'from-yellow-400 to-orange-500',
      technologies: ['Google Maps API', 'Geolocation Services', 'Distance Matrix API'],
    },
    {
      category: 'Authentication',
      icon: Shield,
      color: 'from-red-400 to-rose-500',
      technologies: ['Firebase Auth', 'JWT Tokens', 'OAuth 2.0'],
    },
    {
      category: 'Payments',
      icon: CreditCard,
      color: 'from-indigo-400 to-violet-500',
      technologies: ['Razorpay', 'Payment Gateway', 'Secure Transactions'],
    },
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background-secondary to-background" />
      <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card backdrop-blur-xl border border-border mb-6">
            <Code2 className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Technical Stack</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Technology <span className="text-primary">Stack</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Modern technologies and frameworks powering the Park Easy platform
          </p>
        </motion.div>

        {/* Tech Stack Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {techStack.map((stack, index) => (
            <motion.div
              key={stack.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="group relative"
            >
              <div className="relative h-full p-6 rounded-2xl bg-card backdrop-blur-xl border border-border hover:border-primary/50 transition-all">
                {/* Glow Effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stack.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-all`} />

                <div className="relative space-y-4">
                  {/* Icon & Category */}
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stack.color} p-0.5`}>
                      <div className="w-full h-full rounded-xl bg-background flex items-center justify-center">
                        <stack.icon className={`w-6 h-6 bg-gradient-to-br ${stack.color} bg-clip-text text-transparent`} />
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold">{stack.category}</h3>
                  </div>

                  {/* Technologies */}
                  <div className="space-y-2">
                    {stack.technologies.map((tech) => (
                      <div
                        key={tech}
                        className="px-3 py-2 rounded-lg bg-muted/50 backdrop-blur-sm border border-border text-sm"
                      >
                        {tech}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 text-center"
        >
          <h3 className="text-2xl font-bold mb-4">Development Environment</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div>
              <div className="text-lg font-semibold text-primary mb-2">Version Control</div>
              <p className="text-muted-foreground">Git & GitHub</p>
            </div>
            <div>
              <div className="text-lg font-semibold text-primary mb-2">IDE</div>
              <p className="text-muted-foreground">VS Code</p>
            </div>
            <div>
              <div className="text-lg font-semibold text-primary mb-2">Deployment</div>
              <p className="text-muted-foreground">Cloud Platform</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
